﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BotEcho
{
    public class TourInfo
    {
        public string Destination { get; set; } 

        public string Origin { get; set; }

        public string Date { get; set; }

        public int Days { get; set; }

        public int Persons { get; set; }
    }
}
